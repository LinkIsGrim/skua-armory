logo = "logo_skua_armory_ca.paa";
name = "Skua Armory";
picture = "logo_skua_armory_ca.paa";